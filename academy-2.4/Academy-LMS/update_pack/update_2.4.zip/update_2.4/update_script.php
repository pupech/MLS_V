<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

	// Update version number
	$data = array('value' => '2.4');
	$this->db->where('key', 'version');
	$this->db->update('settings', $data);
?>
